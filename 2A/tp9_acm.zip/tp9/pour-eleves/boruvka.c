#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#include "graph.h"




int main(void){
    FILE* f = fopen("exemple.txt","r");
    graph_t* g = read_graph(f);
    int nb_edges;
    edge* edges = get_edges(g,&nb_edges);
    sort_edges(edges,nb_edges);
    print_edge_array(edges,nb_edges);
    fclose(f);
    return 0;
}
