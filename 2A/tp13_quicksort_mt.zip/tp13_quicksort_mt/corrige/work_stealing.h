#ifndef WORK_STEALING_H
#define WORK_STEALING_H

void parallel_sort_work_stealing(int *arr, int len, int nb_threads);

#endif
