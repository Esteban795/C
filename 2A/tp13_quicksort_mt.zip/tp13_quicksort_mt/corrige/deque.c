#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <pthread.h>
#include <stdbool.h>

#include "deque.h"


struct node {
    slice_t slice;
    struct node *next;
    struct node *prev;
};

typedef struct node node_t;

const slice_t DEFAULT = {.start = NULL, .len = 0};

struct deque {
    node_t *sentinel;
    pthread_mutex_t lock;
};

typedef struct deque deque_t;

node_t *new_node(slice_t data){
    node_t *n = malloc(sizeof(node_t));
    n->next = NULL;
    n->prev = NULL;
    n->slice = data;
    return n;
}

deque_t *new_deque(void){
    deque_t *q = malloc(sizeof(deque_t));
    q->sentinel = new_node(DEFAULT);
    q->sentinel->next = q->sentinel;
    q->sentinel->prev = q->sentinel;
    pthread_mutex_init(&q->lock, NULL);
    return q;
}

bool try_pop_left(deque_t *q, slice_t *result){
    pthread_mutex_lock(&q->lock);
    node_t *head = q->sentinel->next;
    if (head == q->sentinel) {
        pthread_mutex_unlock(&q->lock);
        return false;
    }
    head->prev->next = head->next;
    head->next->prev = head->prev;
    *result = head->slice;
    free(head);
    pthread_mutex_unlock(&q->lock);
    return true;
}

bool try_pop_right(deque_t *q, slice_t *result){
    pthread_mutex_lock(&q->lock);
    node_t *tail = q->sentinel->prev;
    if (tail == q->sentinel) {
        pthread_mutex_unlock(&q->lock);
        return false;
    }
    tail->next->prev = tail->prev;
    tail->prev->next = tail->next;
    *result = tail->slice;
    free(tail);
    pthread_mutex_unlock(&q->lock);
    return true;
}

void push_left(deque_t *q, slice_t data){
    pthread_mutex_lock(&q->lock);
    node_t *n = new_node(data);
    n->prev = q->sentinel;
    n->next = q->sentinel->next;
    n->prev->next = n;
    n->next->prev = n;
    pthread_mutex_unlock(&q->lock);
}

void push_right(deque_t *q, slice_t data){
    pthread_mutex_lock(&q->lock);
    node_t *n = new_node(data);
    n->next = q->sentinel;
    n->prev = q->sentinel->prev;
    n->prev->next = n;
    n->next->prev = n;
    pthread_mutex_unlock(&q->lock);
}


void free_deque(deque_t *q){
    pthread_mutex_lock(&q->lock);
    node_t *n = q->sentinel->next;
    while (n != q->sentinel) {
        node_t *tmp = n->next;
        free(n);
        n = tmp;
    }
    free(q->sentinel);
    pthread_mutex_unlock(&q->lock);
    pthread_mutex_destroy(&q->lock);
    free(q);
}
