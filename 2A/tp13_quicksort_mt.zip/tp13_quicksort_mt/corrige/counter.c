#include <pthread.h>
#include <stdlib.h>
#include <stdatomic.h>

typedef atomic_int counter_t;

counter_t *initialize_counter(int value){
    atomic_int *n = malloc(sizeof(atomic_int));
    *n = value;
    return n;
}

void increment(counter_t *counter){
    (*counter)++;
}


void decrement(counter_t *counter){
    (*counter)--;
}

void set_counter(counter_t *counter, int value){
    *counter = value;
}

int get_counter(counter_t *counter){
    return *counter;
}

void destroy_counter(counter_t *counter){
    free(counter);
}
