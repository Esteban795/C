#include <stdlib.h>
#include <assert.h>
#include <pthread.h>
#include <stdbool.h>

#include "counter.h"
#include "deque.h"
#include "quicksort.h"
#include "global_list.h"

#define MIN_SIZE 1000

struct worker_data {
    deque_t **queues;
    counter_t *nb_tasks;
    int index;
    int nb_workers;
};

typedef struct worker_data worker_data_t;

static bool try_steal(worker_data_t *data, slice_t *slice){
    int index = data->index;
    int n = data->nb_workers;
    for (int i = (index + 1) % n; i != index; i = (i + 1) % n) {
        if (try_pop_left(data->queues[i], slice)) return true;
    }
    return false;
}


static void process_task(worker_data_t *data, slice_t slice){
    if (slice.len < MIN_SIZE) {
        full_sort(slice.start, slice.len);
        decrement(data->nb_tasks);
        return;
    }
    int pivot = partition(slice.start, slice.len);
    slice_t s_lo = {.start = slice.start,
                    .len = pivot};
    slice_t s_hi = {.start = slice.start + pivot + 1,
                    .len = slice.len - pivot - 1};
    increment(data->nb_tasks);
    if (s_hi.len > s_lo.len) {
        push_right(data->queues[data->index], s_hi);
        process_task(data, s_lo);
    } else {
        push_right(data->queues[data->index], s_lo);
        process_task(data, s_hi);
    }
}


static void *worker(void *args){
    worker_data_t data = *(worker_data_t*)args;
    int index = data.index;
    deque_t *q = data.queues[index];
    counter_t *nb_tasks = data.nb_tasks;
    while (get_counter(nb_tasks) != 0) {
        slice_t t;
        if (try_pop_right(q, &t)) {
            process_task(&data, t);
        } else if (try_steal(&data, &t)){
            process_task(&data, t);
        }
    }
    return NULL;
}


void parallel_sort_work_stealing(int *arr, int len, int nb_threads){
    pthread_t *threads = malloc(nb_threads * sizeof(pthread_t));
    deque_t **queues = malloc(nb_threads * sizeof(deque_t*));
    worker_data_t *args = malloc(nb_threads * sizeof(worker_data_t));
    for (int i = 0; i < nb_threads; i++) {
        queues[i] = new_deque();
    }
    slice_t initial = {.start = arr, .len = len};
    push_right(queues[0], initial);
    counter_t *nb_tasks = initialize_counter(1);
    for (int i = 0; i < nb_threads; i++) {
        args[i].queues = queues;
        args[i].nb_tasks = nb_tasks;
        args[i].index = i;
        args[i].nb_workers = nb_threads;
        pthread_create(&threads[i], NULL, worker, &args[i]);
    }
    for (int i = 0; i < nb_threads; i++) {
        pthread_join(threads[i], NULL);
    }
    for (int i = 0; i < nb_threads; i++) {
        free_deque(queues[i]);
    }
    free(threads);
    free(queues);
    free(args);
    destroy_counter(nb_tasks);
}
