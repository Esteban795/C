#ifndef GLOBAL_LIST_H
#define GLOBAL_LIST_H

void parallel_sort_global(int *arr, int len, int nb_threads);

#endif
