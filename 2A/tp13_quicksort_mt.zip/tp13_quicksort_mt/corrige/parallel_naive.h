#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <pthread.h>
#ifndef PARALLEL_NAIVE_H
#define PARALLEL_NAIVE_H

void parallel_sort_naive(int *arr, int len);

#endif
