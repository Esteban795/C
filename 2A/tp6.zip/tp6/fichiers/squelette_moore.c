#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>

#include "dfa.h"

typedef int class;

struct partitioned_dfa {
    dfa *dfa;
    state *ordered_states;
    class *classes;
    int nb_classes;
};

typedef struct partitioned_dfa partitioned_dfa;

void print_int_array(int arr[], int n){
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}


partitioned_dfa *initialize_partition(dfa *a){
    partitioned_dfa* p_dfa = malloc(sizeof(partitioned_dfa));
    int n = a->nb_states;
    p_dfa->nb_classes = 2;
    p_dfa->dfa = a;
    p_dfa->nb_classes = malloc(sizeof(state) * n);
    p_dfa->ordered_states = malloc(sizeof(state) * n);
    int nb_already_accepting = 0;
    int nb_non_accepting = 0;
    for (int q = 0; q < a->nb_states;q++){
        if (a->accepting[q]) {
            p_dfa->ordered_states[n - 1 - nb_already_accepting] = q;
            p_dfa->classes[q] = 1;
            nb_already_accepting++;
        } else {
            p_dfa->ordered_states[nb_non_accepting] = q;
            p_dfa->classes[q] = 0;
            nb_non_accepting++;
        }
    }

    return p_dfa;
}


void zero_out(int t[], int n){
    for (int i = 0; i < n; i++) {
        t[i] = 0;
    }
}

class destination_class(partitioned_dfa *a, state q, letter x){
    state destination_state = a->dfa->delta[q][x];
    return a->classes[destination_state];
}

bool discriminate(partitioned_dfa *a, state q, state r){
    
}

class *refine(partitioned_dfa *a);

int *histogram(partitioned_dfa *a, letter x);

void inplace_prefix_sum(int h[], int nb_values);

void sort_by_transition(partitioned_dfa *a, letter x);

bool step(partitioned_dfa *a);

dfa *to_dfa(partitioned_dfa *a);

dfa *minimize(dfa *a);

int main(int argc, char *argv[]){
    return 0;
}
