#include <stdio.h>
#include <stdint.h>


//Q8

