#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <assert.h>
#include <string.h>

#include "bitpacking.h"
#include "stack.h"

typedef uint32_t cw_t;
typedef uint8_t byte_t;

#define CW_MAX_WIDTH 16
#define DICTFULL (1u << CW_MAX_WIDTH)

const cw_t NO_ENTRY = DICTFULL;
const cw_t NULL_CW = DICTFULL;
const cw_t FIRST_CW = 0x100;
const int CW_MIN_WIDTH = 9;

int VERBOSITY = 0;

struct dict_entry_t {
    cw_t pointer;
    uint8_t byte;
};

typedef struct dict_entry_t dict_entry_t;

struct dict_t {
    cw_t next_available_cw;
    int cw_width;
    dict_entry_t data[DICTFULL];
};

struct dict_t dict;

cw_t inverse_table[DICTFULL][256];


void initialize_dictionary(void){
    dict.next_available_cw = FIRST_CW;
    dict.cw_width = CW_MIN_WIDTH;
    for (cw_t i = 0; i < FIRST_CW; i++) {
        dict.data[i].pointer = NULL_CW;
        dict.data[i].byte = i;
    }
}

cw_t lookup(cw_t cw, uint8_t byte){
    cw_t address = inverse_table[cw][byte];
    if (address >= dict.next_available_cw) return NO_ENTRY;
    dict_entry_t entry = dict.data[address];
    if (entry.pointer == cw && entry.byte == byte) return address;
    return NO_ENTRY;
}

void build_entry(cw_t cw, uint8_t byte, bool compress_mode){
    cw_t next = dict.next_available_cw;
    cw_t next_growth = 1u << dict.cw_width;

    if (next == DICTFULL) return;
    if (compress_mode && next == next_growth) dict.cw_width++;
    if (!compress_mode && next + 1 == next_growth) dict.cw_width++;

    dict.data[next].pointer = cw;
    dict.data[next].byte = byte;

    inverse_table[cw][byte] = next;

    dict.next_available_cw++;
}

void mock_compress(FILE *input_file, FILE *output_file){
    cw_t current_cw = NULL_CW;
    int current_byte = getc(input_file);
    while (current_byte != EOF) {
        if (current_cw == NULL_CW) current_cw = current_byte;
        else {
            cw_t new_cw = lookup(current_cw, (uint8_t)current_byte);
            if (new_cw == NO_ENTRY) {
                fprintf(output_file, "%d ", current_cw);
                build_entry(current_cw, (uint8_t)current_byte, true);
                current_cw = (cw_t)current_byte;
            } else {
                current_cw = new_cw;
            }
        }
        current_byte = getc(input_file);
    }
    fprintf(output_file, "%d", current_cw);
    if (VERBOSITY > 0) {
        fprintf(stderr, "Distinct codewords : %d\n", (int)dict.next_available_cw);
    }
}


void compress(FILE *input_file, FILE *output_file){
    bit_file *bf = bin_initialize(output_file);
    cw_t current_cw = NULL_CW;
    int current_byte = getc(input_file);
    while (current_byte != EOF) {
        if (current_cw == NULL_CW) current_cw = current_byte;
        else {
            cw_t new_cw = lookup(current_cw, (uint8_t)current_byte);
            if (new_cw == NO_ENTRY) {
                output_bits(bf, current_cw, dict.cw_width, false);
                build_entry(current_cw, (uint8_t)current_byte, true);
                current_cw = (cw_t)current_byte;
            } else {
                current_cw = new_cw;
            }
        }
        current_byte = getc(input_file);
    }
    output_bits(bf, current_cw, dict.cw_width, true);
    if (VERBOSITY > 0) {
        fprintf(stderr, "Distinct codewords : %d\n", (int)dict.next_available_cw);
    }
    free(bf);
}

uint8_t decode_cw(FILE *fp, cw_t cw, stack *s){
    if (cw >= dict.next_available_cw) {
        fprintf(stderr, "cw : %d, next_available : %d\n", cw,
                dict.next_available_cw);
        fprintf(stderr, "cw_width : %d\n", dict.cw_width);
        exit(EXIT_FAILURE);
    }
    if (VERBOSITY >= 2) fprintf(stderr, "cw read : %d\n", (int)cw);
    dict_entry_t entry = dict.data[cw];
    while (entry.pointer != NULL_CW) {
        stack_push(s, entry.byte);
        entry = dict.data[entry.pointer];
    }
    stack_push(s, entry.byte);

    while (stack_size(s) > 0) {
        putc(stack_pop(s), fp);
    }

    return entry.byte;
}

uint8_t get_first_byte(cw_t cw){
    dict_entry_t entry = dict.data[cw];
    while (entry.pointer != NULL_CW) {
        entry = dict.data[entry.pointer];
    }
    return entry.byte;
}

void mock_decompress(FILE *input_file, FILE *output_file){
    stack *s = stack_new(DICTFULL);

    cw_t prev_cw;
    cw_t current_cw;
    if (fscanf(input_file, "%d", &prev_cw) == 1) {
        decode_cw(output_file, prev_cw, s);
    }

    while (fscanf(input_file, "%d", &current_cw) == 1) {
        if (current_cw < dict.next_available_cw) {
            uint8_t byte = decode_cw(output_file, current_cw, s);
            build_entry(prev_cw, byte, false);
        } else {
            if (VERBOSITY >= 1) {
                fprintf(stderr, "KwK case, cw = %d\n", (int)current_cw);
            }
            uint8_t byte = get_first_byte(prev_cw);
            build_entry(prev_cw, byte, false);
            decode_cw(output_file, current_cw, s);
        }
        prev_cw = current_cw;
    }

    stack_free(s);
}

void decompress(FILE *input_file, FILE *output_file){
    bit_file *bf = bin_initialize(input_file);
    stack *s = stack_new(DICTFULL);
    bool done = false;

    cw_t prev_cw = input_bits(bf, dict.cw_width, &done);
    if (!done) {
        decode_cw(output_file, prev_cw, s);
    }

    cw_t current_cw = input_bits(bf, dict.cw_width, &done);
    while (!done) {
        if (current_cw < dict.next_available_cw) {
            uint8_t byte = decode_cw(output_file, current_cw, s);
            build_entry(prev_cw, byte, false);
        } else {
            if (VERBOSITY >= 1) {
                fprintf(stderr, "KwK case, cw = %d\n", (int)current_cw);
            }
            uint8_t byte = get_first_byte(prev_cw);
            build_entry(prev_cw, byte, false);
            decode_cw(output_file, current_cw, s);
        }
        prev_cw = current_cw;
        current_cw = input_bits(bf, dict.cw_width, &done);
    }

    stack_free(s);
    free(bf);
}


void print_usage_and_exit(char *command){
    fprintf(stderr, "Usage :\n");
    fprintf(stderr, "  %s c <input-file> <output-file>"
            " to compress in binary mode\n", command);
    fprintf(stderr, "  %s C <input-file> <output-file>"
            " to compress in ascii mode\n", command);
    fprintf(stderr, "  %s d <input-file> <output-file>"
            " to decompress in binary mode\n", command);
    fprintf(stderr, "  %s D <input-file> <output-file>"
            " to decompress in ascii mode\n", command);
    fprintf(stderr, "If only one file is given, output is to stdout.\n");
    fprintf(stderr, "If no file is given, input is from stdin"
            " and output is to stdout.\n");
    exit(EXIT_FAILURE);
}


int main(int argc, char* argv[]){

    FILE *input_file = stdin;
    FILE *output_file = stdout;
    if (argc < 2 || argc > 4 || strlen(argv[1]) != 1) {
        print_usage_and_exit(argv[0]);
    }

    char action = argv[1][0];

    if (argc >= 3) input_file = fopen(argv[2], "rb");
    if (argc >= 4) output_file = fopen(argv[3], "wb");

    if (input_file == NULL) {
        fprintf(stderr, "Cannot open file %s for reading.\n", argv[2]);
        return(EXIT_FAILURE);
    }
    if (output_file == NULL) {
        fprintf(stderr, "Cannot open file %s for writing.\n", argv[2]);
        return(EXIT_FAILURE);
    }

    initialize_dictionary();

    if (action == 'c') compress(input_file, output_file);
    else if (action == 'C') mock_compress(input_file, output_file);
    else if (action == 'd') decompress(input_file, output_file);
    else if (action == 'D') mock_decompress(input_file, output_file);
    else print_usage_and_exit(argv[0]);

    fclose(input_file);
    fclose(output_file);
    return EXIT_SUCCESS;
}
