#include <stdio.h>
#include <stdlib.h>

#define ROWS 800
#define COLS 800

int arr[ROWS][COLS];
int divergence(double xc,double yc,int itermax) {
    int n = 0;
    double re = 0.0;
    double im = 0.0;
    while (re*re + im*im <= 4 && n <= itermax) {
        double temp = re;
        re = re*re - im*im + xc;
        im = 2.* temp * im + yc;
        n++;
    }
    return n;
    
}

double re(int j,double xmin, double xmax) {
    double ratio = (double)j / (COLS- 1);
    return xmin + ratio  * (xmax - xmin);
}

double im(int i,double ymin, double ymax) {
    double ratio = (double)i / (ROWS- 1);
    return ymax + ratio  * (ymin - ymax);
}

void fill_tab(double xmin, double xmax, double ymin, double ymax,int itermax) {
    for (int i = 0; i < ROWS;i++) {
        for (int j = 0;j < COLS;j++) {
            int x = re(j,xmin,xmax);
            int y = im(i,ymin,ymax);
            arr[i][j] = divergence(x,y,itermax);
        }
    }
}

int main(void) {
    
}